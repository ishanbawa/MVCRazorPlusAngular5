export class GlobalVars {

    static MyModuleRef: any = {};

}
