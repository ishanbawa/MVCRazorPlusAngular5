export class LoginModel {
}
